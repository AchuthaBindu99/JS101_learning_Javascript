let character = "u";
if ((character=="a")||(character=="e")||(character=="i")||(character=="o")||(character=="u")){
  console.log("Vowel")
}