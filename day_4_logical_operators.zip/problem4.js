let a =2;
let b =4;
let c =8;

if((a>b)&&(a>c)){
  console.log("a is greater");
}else if((b>a)&&(b>c)){
  console.log("b is greater");
}else {
  console.log("c is greater");
}

//or

((a>b) && (a>c)) ? console.log("a is greater") : ((b>a) && (b>c)) ? console.log("b is greater") : console.log("c is greater");