let ch ="b";
if(!(ch=="a")&&!(ch=="e")&&!(ch=="i")&&!(ch=="o")&&!(ch=="u")){
  console.log("Consonant")
}