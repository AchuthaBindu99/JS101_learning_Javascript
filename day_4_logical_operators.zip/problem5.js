const week =["Sun","Mon","Tues","wednes","Thurs","Fri","satur"]
for(const n of week){
  console.log(n+"day")
}